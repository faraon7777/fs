#!/bin/sh
###############################################################################
#  Copyright (c) 2014-2020 libbitcoin-node developers (see COPYING).
#
#         GENERATED SOURCE CODE, DO NOT EDIT EXCEPT EXPERIMENTALLY
#
###############################################################################

autoreconf -i
